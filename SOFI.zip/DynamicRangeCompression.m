function img_out = DynamicRangeCompression(img_in)
    S = c * log(1 + r);                                                    %�����仯��ʽ
end

