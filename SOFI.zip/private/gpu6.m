function term=gpu6(term,A,B,C,D,E,F)
term=term + A.*B.*C.*D.*E.*F;
