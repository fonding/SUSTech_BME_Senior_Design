function term=gpu7(term,A,B,C,D,E,F,G)
term=term + A.*B.*C.*D.*E.*F.*G;
