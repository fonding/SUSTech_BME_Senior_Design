%Empty function for MATLAB users without parallel computation toolbox.
%
function x=gather(x)
