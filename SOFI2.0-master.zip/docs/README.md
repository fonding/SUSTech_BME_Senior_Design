# SOFI2.0
this package is associated with our manuscript "Moments reconstruction and local dynamic range compression of high order Super-resolution Optical Fluctuation Imaging"

click 'View on Github' above to access the codes.

---------------------------------------------------------------------------------------------------------------------------------
### MIT License

Copyright (c) 2018 Xiyu Yi

Author of the code: Xiyu Yi

Email of the author: xiyu.yi@gmail.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The asociated publication (listed bellow) being properly cited and credited.

Xiyu Yi, Sungho Son, Ryoko Ando, Atsushi Miyawaki and Shimon Weiss, "Moments reconstruction and local dynamic range compression of high order Super-resolution of Optical Fluctuation Imaging", submitted.

Author information (name, email address) shall remain the same in the assocaited script files when used in other packages.

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
