function term=gpu1(term,A)
term=term + A;
