function term=gpu2(term,A,B)
term=term + A.*B;
