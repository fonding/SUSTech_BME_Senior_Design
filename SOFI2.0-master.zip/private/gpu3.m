function term=gpu3(term,A,B,C)
term=term + A.*B.*C;
