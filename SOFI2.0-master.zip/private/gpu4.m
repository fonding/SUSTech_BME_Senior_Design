function term=gpu4(term,A,B,C,D)
term=term + A.*B.*C.*D;
