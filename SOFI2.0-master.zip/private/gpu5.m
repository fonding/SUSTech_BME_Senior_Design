function term=gpu5(term,A,B,C,D,E)
term=term + A.*B.*C.*D.*E;
