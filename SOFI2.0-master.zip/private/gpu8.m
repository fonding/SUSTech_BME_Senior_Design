function term=gpu8(term,A,B,C,D,E,F,G,H)
term=term + A.*B.*C.*D.*E.*F.*G.*H;
