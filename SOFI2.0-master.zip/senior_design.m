clc,clear,close all;

im1 = aviread('4_order_mSOFI.avi',1);