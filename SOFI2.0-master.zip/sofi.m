function grid=sofi(orders)
    persistent grids hashs
    if isempty(grids)
        disp(1)
    else
        disp(0)
    end
end
