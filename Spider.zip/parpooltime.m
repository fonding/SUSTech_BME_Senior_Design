clc,clear,close all;
t1 = cputime;
parpool;
t2 = cputime;
t = t2-t1;